/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package app;
import model.*;

/**
 *
 * @author camil
 */
public class Salmontt_S3 {

    public static void main(String[] args) {
        
    
        /** Crear objetos utilizando los constructores de las clases Dirección y Persona
        */
        Dirección dire1 = new Dirección ("Los Maitenes", "Santiago", "Metropolitana");
        Persona pers1 = new Persona ("Andrea", "Administrador", 1890000, dire1);
            //Primer objeto creado en el main
        
        Dirección dire2 = new Dirección ("Júpiter", "Osorno", "Los Lagos");
        Persona pers2 = new Persona ("Luisa", "Agropecuaria", 17500000, dire2);
            // Segundo objeto creado en el main
        
        Dirección dire3 = new Dirección ("Estrella Solitaria", "Ñuñoa", "Metropolitana");
        Persona pers3 = new Persona ("Jaime", "Relacionador Público", 14900000, dire3);
            // Tercer objeto creado en el main
            
         /** Mostrar resultado a través de la consola
          */
        System.out.println(pers1.toString());
        System.out.println(pers2.toString());
        System.out.println(pers3.toString());
    
    }
}
