/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author camil
 */
public class Dirección {
    
    /** Clase para reservar la dirección de cada empleado
     * 
     */
    // atributos -> encapsulados
    private String calle, ciudad, región;
    
    // Constructores

    public Dirección() {
    }

    public Dirección(String calle, String ciudad, String región) {
        this.calle = calle;
        this.ciudad = ciudad;
        this.región = región;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getRegión() {
        return región;
    }

    public void setRegión(String región) {
        this.región = región;
    }

    @Override
    public String toString() {
        return "Direcci\u00f3n {" + "calle = " + calle + ", ciudad = " + ciudad + ", regi\u00f3n = " + región + '}';
    }

    
    
    
}

