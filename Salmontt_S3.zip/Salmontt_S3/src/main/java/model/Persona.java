/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author camil
 */
public class Persona {
    
    private String nombre;
    private Dirección dirección; // Persona (superclase - base) tiene una Dirección (subclase)
    public Persona() {
    }

    public Persona(String nombre, String puesto, int salario, Dirección dirección) {
        this.nombre = nombre;
        this.dirección = dirección;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Dirección getDirección() {
        return dirección;
    }

    public void setDirección(Dirección dirección) {
        this.dirección = dirección;
    }

    @Override
    public String toString() {
        return "Persona {" + "nombre = " + nombre + ", direcci\u00f3n = " + dirección + "}";
    }
    
    

   
}
